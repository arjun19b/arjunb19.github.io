To: Professor Musick
From: <Your Name>
Date: <Enter Date>
Subject: Reflection Memo — Project 1: Job Application Portfolio Website

1) Target application analysis
- Organization:
- Values/mission:
- Role requirements (skills, characteristics):
- How my website aligns with those expectations:

2) Two showcased documents
- Document 1 (what it is, why it was chosen, how it supports my candidacy):
- Document 2 (what it is, why it was chosen, how it supports my candidacy):

3) How I incorporated feedback
- Peer feedback highlights and resulting changes:
- Instructor feedback highlights and resulting changes:

4) Challenges and how I addressed them
- Challenge 1 → resolution:
- Challenge 2 → resolution:

(Formatted following Purdue OWL memo conventions.)
